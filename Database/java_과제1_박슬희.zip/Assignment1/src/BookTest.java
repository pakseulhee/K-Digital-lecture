
public class BookTest {

	Book[] b = new Book[100];
	Magazine[] m = new Magazine[100];
	int bookCnt;
	int magazineCnt;

	public void addBook(Book book) {
		b[bookCnt++] = book; //empCnt는 실제 생성된 객체의 수
	}
	
	public void addMagazine(Magazine magazine) {
		m[magazineCnt++] = magazine; //empCnt는 실제 생성된 객체의 수
	}
	
	public void List() {
		System.out.println("************도서목록************");
		for(int i=0; i<bookCnt; i++) {
			System.out.println(b[i].toString());
		}
		for(int i=0; i<magazineCnt; i++) {
			System.out.println(m[i].toString());
		}
		System.out.println();
	}
	
	public static void main(String[] args) {
		BookTest bt = new BookTest();

		bt.addBook(new Book("21424","Java Pro","김하나","Jaen.kr",15000,"기본문법"));
		bt.addBook(new Book("35355","OOAD 분석,설계","소나무","Jaen.kr",30000,""));
		bt.addMagazine(new Magazine("35535","Java World","편집부","androidjava.com",2013,2,7000,""));
		
		bt.List();
	}
}
