package com.mulcam.aop.sample2;

public interface MessageBean {
	public void sayHello();
}
