package com.mulcam.aop.sample3;

public interface MessageBean {
	public void sayHello();
}
