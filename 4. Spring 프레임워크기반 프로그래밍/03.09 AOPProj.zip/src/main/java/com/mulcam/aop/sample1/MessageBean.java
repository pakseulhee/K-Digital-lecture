package com.mulcam.aop.sample1;

public interface MessageBean {
	public void sayHello();
}
