package com.mulcam.di.sample1;

public class MessageBean {
	public void sayHello(String name) {
		System.out.println("Hello, "+name+"!");
	}
}
