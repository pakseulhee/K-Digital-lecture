package com.mulcam.di.sample3;

public class MessageBeanEn implements MessageBean {

	@Override
	public void sayHello(String name) {
		System.err.println("Hello, "+name+"!");
	}

}
