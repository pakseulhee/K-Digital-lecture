package com.mulcam.di.sample4;

public interface MessageBean {
	public void sayHello();
}
