package com.mulcam.di.sample2;

public interface MessageBean {
	public void sayHello(String name);
}
