package com.mulcam.di.sample3;

public interface MessageBean {
	public void sayHello(String name);
}
