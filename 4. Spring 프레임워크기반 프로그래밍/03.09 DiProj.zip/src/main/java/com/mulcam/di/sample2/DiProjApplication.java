package com.mulcam.di.sample2;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiProjApplication {

	public static void main(String[] args) {
		MessageBean bean = new MessageBeanEn();
		bean.sayHello("Spring");
	}

}
