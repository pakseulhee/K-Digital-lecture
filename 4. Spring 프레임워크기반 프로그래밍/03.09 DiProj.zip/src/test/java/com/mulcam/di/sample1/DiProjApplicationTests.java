package com.mulcam.di.sample1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
