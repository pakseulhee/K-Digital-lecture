package sec01.val;

public class InceaTest {

	public static void main(String[] args) {
		int i = 0; 
		System.out.println(++i);//++한 이후 값을 줘요
		System.out.println(i);
		System.out.println(i++);//++하기전의 i값을 줘요

	}
}
