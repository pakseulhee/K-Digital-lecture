public class BookTest {
	
	Book[] b = new Book[100];
	Magazine[] m = new Magazine[100];
	int bookCnt;
	int magazineCnt;

	public void addBook(Book book) {
		b[bookCnt++] = book; //empCnt는 실제 생성된 객체의 수
	}
	
	public void addMagazine(Magazine magazine) {
		m[magazineCnt++] = magazine; //empCnt는 실제 생성된 객체의 수
	}
	
	public void bookList() {
		System.out.println("************도서목록************");
		for(int i=0; i<bookCnt; i++) {
			System.out.println(b[i].toString());
		}
		System.out.println();
	}
	
	public void magazineList() {
		System.out.println("************잡지목록************");
		for(int i=0; i<magazineCnt; i++) {
			System.out.println(m[i].toString());
		}
		System.out.println();
	}


	

	public static void main(String[] args) {
		BookTest bt = new BookTest();
		
		bt.addBook(new Book("21424","Java Basic","김하나","Jaen.kr",15000,"기본문법"));
		bt.addBook(new Book("33455","JDBX Pro","김철수","Jaen.kr",23000));
		bt.addBook(new Book("55355","Servlet/JSP","박자바","Jaen.kr",41000,"Model2 기반"));
		bt.addBook(new Book("35332","Android App","홍길동","Jaen.kr",25000,"Lightweight Framework"));
		bt.addBook(new Book("35355","OOAD 분석,설계","소나무","Jaen.kr",30000));
		bt.addMagazine(new Magazine("35535","Java World","편집부","Jaen.kr",7000,2013,2));
		bt.addMagazine(new Magazine("33434","Mobile World","편집부","Jaen.kr",8000,2013,8));
		bt.addMagazine(new Magazine("75342","Next Web","편집부","Jaen.kr",10000,"AJAX 소개",2012,10));
		bt.addMagazine(new Magazine("76543","Architecture","편집부","Jaen.kr",5000,"java 시스템",2010,3));
		bt.addMagazine(new Magazine("76534","Data Modeling","편집부","Jaen.kr",14000,2012,12));
		
		bt.bookList();
		bt.magazineList();
	}

}
