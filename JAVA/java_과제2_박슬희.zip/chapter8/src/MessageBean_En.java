public class MessageBean_En implements MessageBean {
	public void sayHello(String mean) {
		System.out.println("JAVA");
	}
}
