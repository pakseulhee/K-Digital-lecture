public class MessageBean_kr implements MessageBean {
	public void sayHello(String mean) {
		System.out.println("자바");
	}
}
