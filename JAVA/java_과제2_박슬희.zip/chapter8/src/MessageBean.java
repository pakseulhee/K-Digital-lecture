public interface MessageBean {
	public void sayHello(String mean);
}
