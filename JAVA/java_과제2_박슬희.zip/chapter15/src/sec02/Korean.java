package sec02;

public class Korean {
	String juminNo;
	String name;
	String addr;
	public Korean(String juminNo, String name, String addr) {
		this.juminNo = juminNo;
		this.name = name;
		this.addr = addr;
	}
}
