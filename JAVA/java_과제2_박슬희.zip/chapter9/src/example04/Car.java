package example04;

public class Car {
	class Tire{}
	static class Engine {}
}
