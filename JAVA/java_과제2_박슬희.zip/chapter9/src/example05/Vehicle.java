package example05;

public interface Vehicle {
	public void run();
}
