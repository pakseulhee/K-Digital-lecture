abstract class MyObject{
	int n;
	public void method1() {}
	public abstract void method2();
}

public class AbstractSample {

	public static void main(String[] args) {
//		MyObject mo = new MyObject(); 추상클래스는 인스턴스화할 수 없다.
	}

}
